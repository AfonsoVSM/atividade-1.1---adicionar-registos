<form action="<?php echo e(route('livros.store')); ?>" method="post"> 
<?php echo csrf_field(); ?>
Titulo: <input type="text" name="titulo"><br><br>
Idioma: <input type="text" name="idioma"><br><br>
Total páginas: <input type="text" name="total_paginas"><br><br>
Data Edição: <input type="text" name="data_edicao"><br><br>
ISBN: <input type="text" name="isbn"><br><br>
Observaçoes: <textarea name="obsevacoes"></textarea><br><br>
Imagem capa: <input type="text" name="imagem_capa"><br><br>
Género: <input type="text" name="genero"><br><br>
Autor: <input type="text" name="autor"><br><br>
Sinopse: <textarea name="sinopse"></textarea><br><br>
<input type="submit" name="enviar">
</form><?php /**PATH D:\Atividade6\livraria\resources\views/livros/create.blade.php ENDPATH**/ ?>